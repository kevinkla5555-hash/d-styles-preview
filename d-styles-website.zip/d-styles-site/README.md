# Nieuwe website D-Styles

Complete, Nederlandstalige website voor D-Styles Design office & Daan D-Styles Art.
Statische site: geen WordPress, geen plugins en geen database nodig. Daardoor snel, veilig en goedkoop te hosten.

## Wat erin zit

| Onderdeel | Pagina's |
|---|---|
| Home | `/` |
| Interieurontwerp (woningen + bedrijven, werkwijze, FAQ) | `/interieurontwerp/` |
| Projecten + 11 projectpagina's met fotogalerij | `/projecten/…` |
| Kunst: collectie met filters, sortering en "op ware grootte" | `/kunst/` |
| 61 kunstwerkpagina's met prijs, specificaties en grootte-visual | `/kunst/<naam>/` |
| Inspiratie: 5 adviesartikelen die koopvragen beantwoorden | `/inspiratie/…` |
| Over Daan, met feitenblok "D-Styles in het kort" | `/over-daan/` |
| Contact (formulier + FAQ) | `/contact/` |
| Foutpagina | `/404.html` |

**Wow-momenten**
- *Openingsmoment*: de homepage opent schermvullend op het kunstwerk Proud. Tijdens het scrollen zoomt het uit tot het ingelijst aan de wand hangt en de kop verschijnt. Wie "minder beweging" heeft ingesteld, krijgt meteen de eindstand.
- *Vloeiende paginaovergangen*: een kunstwerk of project schuift van het overzicht naar zijn eigen pagina (Chrome, Edge en Safari; andere browsers laden gewoon de pagina).
- *Bekijk aan de wand*: op elke kunstwerkpagina een voorbeeldkamer met vijf wandkleuren, of een eigen foto van de wand waarop het werk op ware grootte te verslepen is. De foto blijft op het apparaat van de bezoeker.
- *Projecten als raster of lijst*, met een foto die met de muis meebeweegt.
- *Kunst op ware grootte*: alle werken op dezelfde schaal en aan één wand op museumhoogte.

**Premium laag (animaties)**
- Laadscherm met woordmerk, één keer per sessie; daarna rijzen de woorden van de kop op.
- Soepel scrollen (Lenis), header die verdwijnt bij omlaag scrollen en terugkomt bij omhoog.
- Eigen cursor met labels ("Bekijk", "Sleep") op muisapparaten; magnetische knoppen met invullende hover.
- Beelden onthullen zich met een velvet-paneel; koppen komen op uit een afgesneden lijn; rasters trapsgewijs.
- Kunstkaarten kantelen in 3D mee met de muis; op de kunstwerkpagina een loupe die de textuur 2,4× vergroot.
- Schermvullend mobiel menu, marquee met titels van werken, parallax op projectbeelden.
- Alles schakelt uit bij "minder beweging" in het besturingssysteem.

**Snelheid**
- Geen frameworks; alleen Lenis (19 KB) voor soepel scrollen. Eigen script ±22 KB, CSS ±45 KB.
- Lettertypes zitten in `assets/fonts.css` (ingesloten), zodat ze op elke hosting én lokaal laden; het openingsbeeld krijgt voorrang bij het laden.
- Ruimte voor foto's wordt vooraf vastgelegd, zodat de pagina niet verspringt (gemeten CLS 0 tot 0,04; de norm van Google is onder 0,1).
- Na het verhuizen van de foto's maakt `build/afbeeldingen.py` automatisch kleinere varianten (640, 1280, 1920 px). Elke foto krijgt dan srcset, width en height, zodat telefoons geen grote bestanden downloaden.

**Ingebouwd om te verkopen**
- Op elke kunstwerkpagina twee knoppen: *Bestellen* (of *Direct kopen* met een betaallink) en *Vraag via WhatsApp*, met een kant-en-klaar bericht inclusief link naar het werk.
- Een vaste koopbalk met naam, prijs en knop zodra de bezoeker verder scrolt.
- Advies op basis van een foto van de wand, en verwijzingen naar de adviesartikelen voor wie twijfelt.
- Zekerheden direct onder de prijs: gesigneerd met certificaat, maximaal drie exemplaren, ander formaat mogelijk, verzendkosten.
- Filter *In de aanbieding* in de collectie; bij hover verschijnt een tweede beeld (detail of sfeer).
- Ruimte voor echte klantreacties (`TESTIMONIALS` in data.py); zolang die leeg is, wordt de sectie niet getoond.

**Ingebouwd voor vindbaarheid**
- Eigen Nederlandse titel en meta-omschrijving per pagina, één H1 per pagina en beschrijvende alt-teksten.
- Structured data (schema.org): bedrijf met adres, persoon, diensten, FAQ, kruimelpad, en per kunstwerk een Product met prijs, verzendkosten en afmetingen. Daardoor kunnen kunstwerken met prijs in Google verschijnen.
- `sitemap.xml` inclusief alle foto's (voor Google Afbeeldingen) en `robots.txt` die zoekmachines en AI-assistenten expliciet toelaat.
- `google-shopping.xml`: productfeed met alle 61 werken voor **gratis vermeldingen in Google Shopping**, Afbeeldingen en Lens. Ook bruikbaar als Pinterest-catalogus.
- Productgegevens voor Pinterest en sociale media (prijs, merk, beschikbaarheid) op elke kunstwerkpagina.
- *GEO (vindbaar in AI-antwoorden)*: adviesartikelen die beginnen met een kort, zelfstandig antwoord; een feitenblok met bedrijfsgegevens; `llms.txt` met een samenvatting. Let op: van llms.txt is niet bewezen dat AI-systemen het gebruiken. Wat wél aantoonbaar helpt, is goed scoren in Google en vermeld worden op andere sites (zie *Na livegang*).
- 301-doorverwijzingen van alle oude WordPress-adressen naar de nieuwe (`_redirects` en `.htaccess`). Zo gaat de opgebouwde vindbaarheid niet verloren.
- Lettertypes staan op de eigen server (geen Google Fonts), zonder cookies of trackers. Daarom is er geen cookiebanner nodig.

## Bekijken op je eigen computer

Open `index.html` in je browser. Links werken ook lokaal.

## Aanpassen

Alle inhoud staat in **`build/data.py`**: teksten, prijzen, actieprijzen, foto's, projecten en veelgestelde vragen.
Na een wijziging draai je:

```
python3 build/build.py
```

Een nieuw kunstwerk toevoegen = één regel in de lijst `A` in `data.py`. De pagina, de sitemap, de doorverwijzing en de structured data worden automatisch gemaakt.

## Vóór livegang: checklist

1. **Akkoord van Daan** op ontwerp, teksten en prijzen, en laat haar de vijf adviesartikelen nalezen.
2. **Foto's verhuizen.** De foto's komen nu nog van de huidige WordPress-site. Download de map `wp-content/uploads` (via FTP of de hostingprovider) naar `assets/img/`. Zet daarna in `build/data.py` `IMG_BASE = "/assets/img/"`, draai `python3 build/afbeeldingen.py` (maakt de snelle varianten) en daarna `python3 build/build.py`. Zonder deze stap verdwijnen de foto's zodra WordPress offline gaat.
3. **Kopen regelen.** `BUY_MODE` in `data.py`:
   - `"webshop"` (nu): de knop *Bestellen* gaat naar de bestaande WooCommerce-productpagina. Dat werkt alleen zolang die webshop blijft bestaan, bijvoorbeeld op `shop.d-styles.nl` (pas dan `WEBSHOP_URL` aan).
   - `"aanvraag"`: geen webshop, de bezoeker vraagt het werk per mail aan en Daan stuurt een betaallink (bijv. Mollie, Stripe of Tikkie).
   - **Aanrader:** maak per werk een betaallink aan in Mollie (iDEAL, creditcard, Bancontact) of Stripe en zet die in `PAY_LINKS` in data.py. De hoofdknop wordt dan *Direct kopen*, zonder webshop.
   - Controleer of 06 20 41 16 60 WhatsApp heeft (`WHATSAPP` in data.py; zet op `None` om uit te zetten).
   - Laat Daan bevestigen dat ze advies op basis van een foto wil geven; anders die tekst aanpassen.
4. **Juridische pagina's overzetten.** Privacyverklaring, algemene voorwaarden en retourbeleid staan nu nog op de oude site. Zet deze teksten over en pas de links in `LEGAL` (data.py) aan.
5. **KvK-nummer en btw-nummer** toevoegen in de footer (verplicht voor een webshop).
6. **Hosting.** Eenvoudigste opties: Netlify of Cloudflare Pages (gratis, gebruikt `_redirects`) of de huidige hosting met Apache (gebruikt `.htaccess`). Upload de hele map, behalve `build/` en `README.md`.

## Na livegang: vindbaarheid

1. Google Search Console: domein toevoegen en `https://d-styles.nl/sitemap.xml` indienen.
2. Google Bedrijfsprofiel aanmaken of claimen (categorie *Interieurontwerper*, adres Boekel), met projectfoto's.
3. Bing Webmaster Tools koppelen (importeert Search Console).
4. Klanten om een Google-review vragen.
5. Gratis vermeldingen: Houzz, Homify, Trustoo, Werkspot, KvK.
6. Pinterest: elk kunstwerk pinnen met link naar de eigen kunstwerkpagina.
7. Rich Results Test van Google gebruiken op een kunstwerkpagina om de structured data te controleren.
8. **Google Merchant Center** (gratis): account aanmaken, website verifiëren, `https://d-styles.nl/google-shopping.xml` toevoegen als feed, verzendkosten en retourbeleid invullen. De werken kunnen dan met foto en prijs in Google Shopping verschijnen, zonder advertentiekosten.
9. **Pinterest bedrijfsaccount**: website claimen en dezelfde feed toevoegen als catalogus.
10. **Vermeldingen buiten de eigen site** (belangrijk voor AI-antwoorden): Google-reviews, Houzz, lokale pers (bijv. een artikel over een kunstenaar uit Boekel), en klanten of leveranciers die naar het project linken.
11. Elke paar maanden een nieuw werk of project toevoegen: actuele sites worden vaker genoemd.
